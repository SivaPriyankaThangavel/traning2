package org.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cts.Emp;
import org.cts.EmpDao;

import com.google.gson.Gson;
@WebServlet("/getDetails")
public class EmpController extends HttpServlet 
{
	EmpDao dao=new EmpDao();
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		resp.setContentType("text/html");
		PrintWriter pw=resp.getWriter();
		List<Emp> emps=dao.getEmployees();
		Gson gson=new Gson();
		String jsonRes=gson.toJson(emps);
		System.out.println(jsonRes);
		pw.println(jsonRes);
		pw.close();
	}
}
