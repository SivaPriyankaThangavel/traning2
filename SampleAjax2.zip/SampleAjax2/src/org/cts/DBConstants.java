package org.cts;


public class DBConstants {
	public static final String DRIVER="com.mysql.jdbc.Driver";
	public static final String URL="jdbc:mysql://localhost:3306/employees";
	public static final String UNAME="root";
	public static final String PWD="root";
}
