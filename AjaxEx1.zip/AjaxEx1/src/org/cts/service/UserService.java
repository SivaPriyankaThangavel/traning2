package org.cts.service;

import org.cts.beans.User;

public interface UserService {
	User validateUser(int uid);
}
